package model;

import enums.ActionLetter;

public class Mars extends Product {
    public Mars(ActionLetter actionLetter, int price) {
        super("Mars", actionLetter, price);
    }
}
