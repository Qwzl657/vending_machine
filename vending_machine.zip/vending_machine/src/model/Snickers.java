package model;

import enums.ActionLetter;

public class Snickers extends Product {
    public Snickers(ActionLetter actionLetter, int price) {
        super("Snickers", actionLetter, price);
    }
}
