package model;

public interface MoneyAcceptor {
    int getAmount();
    void setAmount(int amount);
    void addAmount(int delta);
}