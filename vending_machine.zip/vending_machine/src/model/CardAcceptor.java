package model;

import java.util.Scanner;


public class CardAcceptor implements MoneyAcceptor {

    private int amount;

    public CardAcceptor() {
        this.amount = 0;
    }

    private String input(String msg) {
        System.out.print(msg + ": ");
        return new Scanner(System.in).nextLine().trim();
    }


    public boolean processCardPayment() {
        System.out.println("=== Оплата картой ===");


        String card = input("Введите номер карты (16 цифр)");
        if (!card.matches("\\d{16}")) {
            System.out.println("Ошибка: номер карты должен содержать 16 цифр.");
            return false;
        }


        String cvv = input("Введите CVV (3 цифры)");
        if (!cvv.matches("\\d{3}")) {
            System.out.println("Ошибка: CVV должен состоять из 3 цифр.");
            return false;
        }


        String otp = input("Введите одноразовый пароль (4 цифры)");
        if (!otp.matches("\\d{4}")) {
            System.out.println("Ошибка: пароль должен состоять из 4 цифр.");
            return false;
        }

        System.out.println("Оплата подтверждена.");
        return true;
    }

    @Override
    public int getAmount() {
        return amount;
    }

    @Override
    public void setAmount(int amount) {
        this.amount = amount;
    }

    @Override
    public void addAmount(int delta) {
        this.amount += delta;
    }
}