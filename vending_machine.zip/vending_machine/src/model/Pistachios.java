package model;

import enums.ActionLetter;

public class Pistachios extends Product {
    public Pistachios(ActionLetter actionLetter, int price) {
        super("Pistachios", actionLetter, price);
    }
}
