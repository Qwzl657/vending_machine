import enums.ActionLetter;
import model.*;
import util.UniversalArray;
import util.UniversalArrayImpl;

import java.util.Scanner;



public class AppRunner {

    private final UniversalArray<Product> products = new UniversalArrayImpl<>();
    private final MoneyAcceptor moneyAcceptor;
    private static boolean isExit = false;

    private AppRunner() {
        products.addAll(new Product[]{
                new Water(ActionLetter.B, 20),
                new CocaCola(ActionLetter.C, 50),
                new Soda(ActionLetter.D, 30),
                new Snickers(ActionLetter.E, 80),
                new Mars(ActionLetter.F, 80),
                new Pistachios(ActionLetter.G, 130)
        });


        moneyAcceptor = new CardAcceptor();

    }

    public static void run() {
        AppRunner app = new AppRunner();
        while (!isExit) {
            app.startSimulation();
        }
    }

    private void startSimulation() {
        System.out.println("В автомате доступны:");
        showProducts(products);

        System.out.println("Баланс: " + moneyAcceptor.getAmount());

        UniversalArray<Product> allowed = getAllowedProducts();

        if (allowed.size() == 0) {
            System.out.println("Ничего не купишь. Пополни баланс.");
        } else {
            System.out.println("Доступные товары:");
            showActions(allowed);
        }

        System.out.println("\nКоманды:");
        System.out.println("  - число: пополнение наличными");
        System.out.println("  - card: оплата картой");
        System.out.println("  - буква товара: купить товар");
        System.out.println("  - h: выход");

        chooseAction(allowed);
    }

    private UniversalArray<Product> getAllowedProducts() {
        UniversalArray<Product> allowed = new UniversalArrayImpl<>();
        for (int i = 0; i < products.size(); i++) {
            if (moneyAcceptor.getAmount() >= products.get(i).getPrice()) {
                allowed.add(products.get(i));
            }
        }
        return allowed;
    }

    private void chooseAction(UniversalArray<Product> allowed) {
        while (true) {
            String input = fromConsole().trim().toLowerCase();

            // === ВЫХОД ===
            if (input.equals("h")) {
                isExit = true;
                return;
            }


            if (input.equals("card")) {

                if (!(moneyAcceptor instanceof CardAcceptor)) {
                    System.out.println("Этот автомат не принимает карты.");
                    return;
                }

                CardAcceptor card = (CardAcceptor) moneyAcceptor;

                if (!card.processCardPayment()) {
                    System.out.println("Оплата отклонена.");
                    return;
                }

                System.out.println("Введите сумму пополнения:");
                String sum = fromConsole().trim();

                if (!isInteger(sum)) {
                    System.out.println("Ошибка: нужно число.");
                    return;
                }

                int amount = Integer.parseInt(sum);
                card.addAmount(amount);

                System.out.println("Баланс пополнен на " + amount);
                return;
            }


            if (isInteger(input)) {
                moneyAcceptor.addAmount(Integer.parseInt(input));
                return;
            }


            boolean found = false;
            for (int i = 0; i < allowed.size(); i++) {
                Product p = allowed.get(i);
                if (p.getActionLetter().getValue().equals(input)) {
                    moneyAcceptor.setAmount(moneyAcceptor.getAmount() - p.getPrice());
                    System.out.println("Вы купили: " + p.getName());
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("Нет такого действия.");
            } else return;
        }
    }

    private String fromConsole() {
        return new Scanner(System.in).nextLine();
    }

    private boolean isInteger(String s) {
        try { Integer.parseInt(s); return true; }
        catch (Exception e) { return false; }
    }

    private void showProducts(UniversalArray<Product> products) {
        for (int i = 0; i < products.size(); i++) {
            System.out.println(products.get(i));
        }
    }

    private void showActions(UniversalArray<Product> products) {
        for (int i = 0; i < products.size(); i++) {
            Product p = products.get(i);
            System.out.println(" " + p.getActionLetter().getValue() + " - " + p.getName());
        }
    }
}